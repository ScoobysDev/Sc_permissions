local QBCore = exports['qb-core']:GetCoreObject()

local validGroups = {
    user = true,
    mod = true,
    admin = true,
    developer = true,
    superadmin = true,
    owner = true
}

QBCore.Commands.Add("setgroup", "Change a player's group", {{name = "id", help = "Player ID"}, {name = "group", help = "Group name"}}, true, function(source, args)
    local src = source
    local targetId = tonumber(args[1])
    local newGroup = string.lower(args[2])
    local Player = QBCore.Functions.GetPlayer(src)
    local Target = QBCore.Functions.GetPlayer(targetId)

    if not Player or not Target then
        TriggerClientEvent('QBCore:Notify', src, "Invalid player ID", "error")
        return
    end

    local srcGroup = Player.PlayerData.group or "user"

    if srcGroup ~= "superadmin" and srcGroup ~= "owner" then
        TriggerClientEvent('QBCore:Notify', src, "You don't have permission to use this command", "error")
        return
    end

    if not validGroups[newGroup] then
        TriggerClientEvent('QBCore:Notify', src, "Invalid group name", "error")
        return
    end

    Target.PlayerData.group = newGroup

    MySQL.update('UPDATE players SET `group` = ? WHERE citizenid = ?', {newGroup, Target.PlayerData.citizenid})

    TriggerClientEvent('QBCore:Notify', targetId, "Your group has been changed to: " .. newGroup, "success")
    TriggerClientEvent('QBCore:Notify', src, "You updated the player's group", "success")
end)

QBCore.Functions.CreateCallback('permissions:getGroup', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if Player then
        cb(Player.PlayerData.group or "user")
    else
        cb("user")
    end
end)