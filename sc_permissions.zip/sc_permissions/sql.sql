-- Add group column to players table
ALTER TABLE `players` ADD COLUMN `group` VARCHAR(50) NOT NULL DEFAULT 'user';
